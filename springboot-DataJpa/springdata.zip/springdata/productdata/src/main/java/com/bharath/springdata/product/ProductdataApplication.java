package com.bharath.springdata.product;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProductdataApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProductdataApplication.class, args);
	}
}
