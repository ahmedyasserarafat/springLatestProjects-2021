package com.bharath.springdata.hibernateinheritance;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HibernateinheritanceApplication {

	public static void main(String[] args) {
		SpringApplication.run(HibernateinheritanceApplication.class, args);
	}
}
