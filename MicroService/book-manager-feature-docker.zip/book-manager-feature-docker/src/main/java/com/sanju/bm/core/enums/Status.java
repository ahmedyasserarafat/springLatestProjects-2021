package com.sanju.bm.core.enums;

public enum Status {
   ACTIVE,INACTIVE,DELETED;
}
