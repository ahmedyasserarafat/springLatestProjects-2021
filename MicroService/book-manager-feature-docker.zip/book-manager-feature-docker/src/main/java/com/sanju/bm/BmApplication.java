package com.sanju.bm;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


@SpringBootApplication
//@EnableEurekaClient
//@EnableDiscoveryClient
public class BmApplication {

	public static void main(String[] args) {
		SpringApplication.run(BmApplication.class, args);
	}

}
